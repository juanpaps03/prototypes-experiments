from typing import Any

from fastapi import FastAPI, Depends, APIRouter

from inbound_data_gateway.api.example_data import example_data_router
from inbound_data_gateway.settings import app_settings
from auth.external_auth import ExternalJwtAuthentication
from auth.issuers import Issuers
from auth.jwt import JWTBearer

app = FastAPI()
security = JWTBearer(internal_jwt_auth=ExternalJwtAuthentication(Issuers.INBOUND_DATA_GATEWAY))

@app.get("/healthcheck")
async def healthcheck() -> Any:
    return {"status": "ok", "version": app_settings.build_version}


api_router = APIRouter()

api_router.include_router(example_data_router, prefix="/example-data")



pipeline = [Depends(security)]

app.include_router(api_router, dependencies=pipeline)